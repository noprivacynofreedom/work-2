import { useCallback, useEffect, useState } from 'react';
import { invoke } from '@tauri-apps/api/core';

type Health = { atlas_api: boolean; llama_swap: boolean; atlas_api_detail: string; llama_detail: string };
type Metrics = { cpu_percent: number; memory_used_bytes: number; memory_total_bytes: number };
type Gpu = { name: string; vendor: string; vram_total_mb: number | null; vram_free_mb: number | null; utilization_percent: number | null; source: string };
type NodeStatus = { node_id:string; enabled:boolean; registered:boolean; remote_workloads_allowed:boolean; cpu_percent:number; memory_total_mb:number; memory_available_mb:number; gpus:Gpu[]; gateway_configured:boolean; trusted_scheduler_configured:boolean; sandbox_available:boolean; local_ledger_entries:number };
type NodeConfig = { enabled:boolean; allow_remote_workloads:boolean; allow_networked_inference:boolean; max_cpu_percent:number; max_memory_mb:number; gateway_url:string; ollama_url:string; trusted_scheduler_key_hex:string; allowed_images:string[]; registered:boolean };


function ModelRuntimeControls() {
  const [models,setModels]=useState<string[]>([]);
  const [selected,setSelected]=useState("coder");
  const [status,setStatus]=useState("Checking runtime…");
  const [busy,setBusy]=useState(false);
  const [loaded,setLoaded]=useState(false);
  const refresh=useCallback(async()=>{
    try { const found=await invoke<string[]>("runtime_models"); setModels(found); if(found.length&&!found.includes(selected))setSelected(found.includes("coder")?"coder":found[0]); setStatus("Runtime available"); }
    catch(e){setStatus(`Runtime unavailable: ${String(e)}`);}
  },[selected]);
  useEffect(()=>{void refresh();},[refresh]);
  const start=async()=>{
    setBusy(true);setStatus(`Loading ${selected}…`);
    try { const result=await invoke<string>("start_model",{model:selected});setLoaded(true);setStatus(result); }
    catch(e){setStatus(String(e));setLoaded(false);}
    finally{setBusy(false);}
  };
  const stop=async()=>{
    setBusy(true);setStatus("Unloading active models…");
    try { const result=await invoke<string>("unload_models");setLoaded(false);setStatus(result); }
    catch(e){setStatus(String(e));}
    finally{setBusy(false);}
  };
  return <div className="runtime-controls" title={status}>
    <span className={`runtime-indicator ${loaded?"loaded":""}`}/>
    <select aria-label="Local model" value={selected} onChange={e=>setSelected(e.target.value)} disabled={busy||!models.length}>
      {models.length?models.map(m=><option key={m} value={m}>{m}</option>):<option value="coder">coder</option>}
    </select>
    <button className="runtime-start" onClick={()=>void start()} disabled={busy||!selected}>{busy?"WORKING…":"START MODEL"}</button>
    <button className="runtime-stop" onClick={()=>void stop()} disabled={busy}>UNLOAD</button>
  </div>;
}

function NodeDashboard() {
  const [status,setStatus]=useState<NodeStatus|null>(null); const [config,setConfig]=useState<NodeConfig|null>(null);
  const [models,setModels]=useState<string[]>([]); const [model,setModel]=useState(''); const [benchmark,setBenchmark]=useState<any>(null);
  const [network,setNetwork]=useState<any>(null); const [ledger,setLedger]=useState<any>(null); const [busy,setBusy]=useState(''); const [notice,setNotice]=useState(''); const [error,setError]=useState('');
  const refresh=useCallback(async()=>{try{const [s,c,l]=await Promise.all([invoke<NodeStatus>('node_status'),invoke<NodeConfig>('node_config_view'),invoke<any>('node_contribution_ledger')]);setStatus(s);setConfig(c);setLedger(l);}catch(e){setError(String(e));}},[]);
  const loadModels=useCallback(async()=>{try{const m=await invoke<any>('node_local_models');const names=(m.models||[]).map((x:any)=>x.name as string);setModels(names);if(names.length)setModel(current=>current||names[0]);}catch(e){setError(`Local model discovery: ${String(e)}`);}},[]);
  useEffect(()=>{void refresh();void loadModels();const t=window.setInterval(()=>void refresh(),10000);return()=>window.clearInterval(t);},[refresh,loadModels]);
  const run=async(label:string,fn:()=>Promise<any>)=>{setBusy(label);setError('');setNotice('');try{const v=await fn();setNotice(typeof v==='string'?v:JSON.stringify(v));await refresh();return v;}catch(e){setError(String(e));return null;}finally{setBusy('');}};
  if(!config)return <div className="node-page"><p>Loading Atlas Node profile…</p>{error&&<pre className="node-error">{error}</pre>}</div>;
  const save=()=>run('save',async()=>{await invoke('node_configure',{gatewayUrl:config.gateway_url,ollamaUrl:config.ollama_url,trustedSchedulerKeyHex:config.trusted_scheduler_key_hex,allowedImages:config.allowed_images});await invoke('node_update_policy',{allowRemoteWorkloads:config.allow_remote_workloads,allowNetworkedInference:config.allow_networked_inference,maxCpuPercent:config.max_cpu_percent,maxMemoryMb:config.max_memory_mb});return 'Node configuration saved.';});
  const toggle=async(enabled:boolean)=>run('consent',async()=>{await invoke('node_set_enabled',{enabled});return enabled?'Atlas Node enabled locally. Remote execution remains separately disabled.':'Atlas Node disabled; remote permissions revoked.';});
  const register=()=>run('register',()=>invoke('node_register'));
  const refreshNetwork=()=>run('network',async()=>{const v=await invoke<any>('node_network_status');setNetwork(v);return v;});
  const doBenchmark=()=>run('benchmark',async()=>{const v=await invoke<any>('node_benchmark_local',{model,prompt:'Explain in one concise sentence what local AI inference means.'});setBenchmark(v);return v;});
  const imagesText=config.allowed_images.join('\n');
  return <main className="node-page">
    <div className="node-heading"><div><div className="eyebrow">ATLAS COMPUTE NETWORK / DEVICE CONTROL</div><h1>Atlas Node</h1><p>Your hardware. Your rules. Contribute compute only when you explicitly allow it.</p></div><button className="node-refresh" onClick={()=>void refresh()} disabled={!!busy}>↻ Refresh</button></div>
    <section className="node-summary">
      <div className="node-state"><span className={status?.enabled?'pulse on':'pulse'}></span><div><small>LOCAL NODE</small><strong>{status?.enabled?'ENABLED':'DISABLED'}</strong><span>{status?.registered?'Identity registered':'Not registered with a gateway'}</span></div></div>
      <div><small>NODE FINGERPRINT</small><code>{status?.node_id?.slice(0,24)||'Generating…'}…</code></div>
      <div><small>AVAILABLE MEMORY</small><strong>{status?`${(status.memory_available_mb/1024).toFixed(1)} GB`:'—'}</strong></div>
      <div><small>LOCAL RECEIPTS</small><strong>{status?.local_ledger_entries??0}</strong></div>
    </section>
    <div className="node-columns">
      <section className="node-panel hardware-panel"><div className="panel-title"><div><span className="eyebrow">01 / MACHINE PROFILE</span><h2>Hardware telemetry</h2></div><span className="live-label">LOCAL</span></div>
        <div className="metric-row"><div><small>CPU LOAD</small><strong>{status?`${status.cpu_percent.toFixed(1)}%`:'—'}</strong></div><div><small>SYSTEM RAM</small><strong>{status?`${(status.memory_total_mb/1024).toFixed(1)} GB`:'—'}</strong></div><div><small>RAM FREE</small><strong>{status?`${(status.memory_available_mb/1024).toFixed(1)} GB`:'—'}</strong></div></div>
        <h3>GPU devices</h3>{status?.gpus.length?status.gpus.map((g,i)=><div className="gpu-card" key={i}><div className="gpu-icon">◈</div><div className="gpu-info"><strong>{g.name}</strong><small>{g.vendor} · {g.source}</small></div><div className="gpu-vram"><strong>{g.vram_total_mb?`${(g.vram_total_mb/1024).toFixed(1)} GB`:'—'}</strong><small>VRAM {g.vram_free_mb!==null?`${g.vram_free_mb} MB free`:'telemetry unavailable'}</small></div></div>):<div className="empty-state">No supported GPU telemetry detected. CPU and memory profiling remain available.</div>}
        <div className="subsection"><div className="panel-title"><div><span className="eyebrow">02 / LOCAL MODEL RUNTIME</span><h2>Model benchmark</h2></div><span className="live-label">LOCAL API</span></div><div className="inline-controls"><select value={model} onChange={e=>setModel(e.target.value)}><option value="">Select local model</option>{models.map(m=><option key={m}>{m}</option>)}</select><button onClick={()=>void loadModels()} disabled={!!busy}>Load models</button><button onClick={doBenchmark} disabled={!model||!!busy}> {busy==='benchmark'?'TESTING…':'Run benchmark'}</button></div>{benchmark&&<div className="benchmark-result"><div><strong>{Number(benchmark.tokens_per_second).toFixed(1)}</strong><small> TOKENS / SEC</small></div><div><strong>{benchmark.wall_time_ms} ms</strong><small> WALL TIME</small></div><div><strong>{benchmark.generated_tokens}</strong><small> GENERATED</small></div></div>}<p className="fineprint">Single local request benchmark. Results vary with model load, quantization, thermal state and prompt; not a certification.</p></div>
      </section>
      <section className="node-panel controls-panel"><div className="panel-title"><div><span className="eyebrow">03 / OWNER CONSENT</span><h2>Contribution controls</h2></div><span className={config.enabled?'status-enabled':'status-disabled'}>{config.enabled?'ACTIVE':'OFF'}</span></div>
        <div className="consent-card"><div><strong>Join Atlas Node</strong><p>Allow this PC to be visible as an available compute node. This does not automatically allow remote workloads.</p></div><button className={config.enabled?'danger-button':'primary-button'} onClick={()=>void toggle(!config.enabled)} disabled={!!busy}>{config.enabled?'Disable node':'Enable node'}</button></div>
        <label className="switch-row"><span><strong>Remote sandbox workloads</strong><small>Run only scheduler-signed jobs in Docker with network disabled and resource limits.</small></span><input type="checkbox" checked={config.allow_remote_workloads} disabled={!config.enabled} onChange={e=>setConfig({...config,allow_remote_workloads:e.target.checked})}/></label>
        <label className="switch-row"><span><strong>Network inference requests</strong><small>Permit this node to participate in routed inference requests.</small></span><input type="checkbox" checked={config.allow_networked_inference} disabled={!config.enabled} onChange={e=>setConfig({...config,allow_networked_inference:e.target.checked})}/></label>
        <div className="limit-setting"><div><strong>CPU ceiling</strong><b>{config.max_cpu_percent}%</b></div><input type="range" min="10" max="100" step="5" value={config.max_cpu_percent} onChange={e=>setConfig({...config,max_cpu_percent:Number(e.target.value)})}/></div>
        <div className="limit-setting"><div><strong>Memory ceiling</strong><b>{(config.max_memory_mb/1024).toFixed(1)} GB</b></div><input type="range" min="512" max={Math.max(512,Math.floor((status?.memory_total_mb||8192)*0.8/512)*512)} step="512" value={config.max_memory_mb} onChange={e=>setConfig({...config,max_memory_mb:Number(e.target.value)})}/></div>
        <div className="subsection"><div className="eyebrow">04 / SECURE REGISTRATION</div><label className="field-label">Atlas gateway URL<input value={config.gateway_url} placeholder="https://api.atlas.example" onChange={e=>setConfig({...config,gateway_url:e.target.value})}/></label><label className="field-label">Local inference endpoint<input value={config.ollama_url} onChange={e=>setConfig({...config,ollama_url:e.target.value})}/></label><label className="field-label">Trusted scheduler Ed25519 public key (hex)<input value={config.trusted_scheduler_key_hex} placeholder="64 hexadecimal characters" onChange={e=>setConfig({...config,trusted_scheduler_key_hex:e.target.value})}/></label><label className="field-label">Allowed container image digests<textarea rows={2} value={imagesText} placeholder={'registry.example/model-worker@sha256:…'} onChange={e=>setConfig({...config,allowed_images:e.target.value.split('\n').map(x=>x.trim()).filter(Boolean)})}/></label><div className="inline-controls"><button onClick={save} disabled={!!busy}>{busy==='save'?'SAVING…':'Save policy'}</button><button onClick={register} disabled={!config.gateway_url||!!busy}>{busy==='register'?'REGISTERING…':status?.registered?'Re-register':'Register node'}</button></div><p className="fineprint">Registration uses a server-issued challenge signed by this device's Ed25519 identity. Remote workload execution requires a separately trusted scheduler key and image allowlist.</p></div>
      </section>
    </div>
    <section className="node-panel network-panel"><div className="panel-title"><div><span className="eyebrow">05 / DISTRIBUTED COMPUTE</span><h2>Network & contribution ledger</h2></div><button onClick={refreshNetwork} disabled={!!busy}>Check network</button></div><div className="network-grid"><div className="network-card"><small>GATEWAY</small><strong>{status?.gateway_configured?'CONFIGURED':'NOT CONFIGURED'}</strong><span>{network?.available?'Reachable':'No confirmed connection'}</span></div><div className="network-card"><small>SANDBOX RUNTIME</small><strong>{status?.sandbox_available?'DOCKER READY':'NOT AVAILABLE'}</strong><span>Signed workload execution only</span></div><div className="network-card"><small>ACCOUNTING</small><strong>LOCAL RECEIPTS</strong><span>Server settlement not yet connected</span></div></div>{network&&<pre className="node-json">{JSON.stringify(network,null,2)}</pre>}<div className="ledger-head"><h3>Contribution receipts</h3><span>EXECUTED ≠ VERIFIED</span></div><pre className="node-json">{JSON.stringify(ledger||{entries:[]},null,2)}</pre><p className="fineprint">Receipts are locally recorded as unverified. Only a trusted platform-signed settlement can establish billable or payable contribution. This desktop package does not claim remote scheduling, settlement or payments are live without the matching gateway services.</p></section>
    {notice&&<div className="node-notice">{notice}</div>}{error&&<pre className="node-error">{error}</pre>}
    <footer className="node-footer">ATLAS NODE · LOCAL-FIRST · OWNER-CONTROLLED · FAIL-CLOSED SECURITY</footer>
  </main>;
}

export default function App() {
  const [health, setHealth] = useState<Health | null>(null); const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [message, setMessage] = useState('Starting Atlas services…'); const [error, setError] = useState(''); const [ready, setReady] = useState(false); const [busy, setBusy] = useState(false); const [view,setView]=useState<'chat'|'node'>('chat');
  const refresh = useCallback(async (): Promise<Health | null> => { try { const [h,m] = await Promise.all([invoke<Health>('health_check'),invoke<Metrics>('system_metrics')]); setHealth(h); setMetrics(m); setReady(h.atlas_api); if(h.atlas_api){setError('');} else {setError(`Atlas API is unavailable: ${h.atlas_api_detail}. llama-swap: ${h.llama_detail}`);} return h; } catch(e){setReady(false);setError(`Desktop health check failed: ${String(e)}`);return null;} },[]);
  const start = useCallback(async () => {setBusy(true);setReady(false);setError('');setMessage('Starting local inference and Atlas API…');try{const result=await invoke<string>('start_legacy_services');setMessage(result);const h=await refresh();if(!h?.atlas_api) throw new Error(h?.atlas_api_detail || 'Atlas API did not pass its health check.');}catch(e){setReady(false);setError(String(e));setMessage('Atlas could not start. See the error and project logs.');}finally{setBusy(false);}},[refresh]);
  useEffect(()=>{void start();const timer=window.setInterval(()=>void refresh(),2500);return()=>window.clearInterval(timer);},[start,refresh]);
  const memoryPct=metrics?.memory_total_bytes?metrics.memory_used_bytes/metrics.memory_total_bytes*100:0;
  if(ready)return <div className="app-frame"><div className="frame-bar"><span>✦ ATLAS // LOCAL DESKTOP</span><div className="frame-status"><i/> API ONLINE</div><ModelRuntimeControls/><nav className="desktop-nav"><button className={view==='chat'?'selected':''} onClick={()=>setView('chat')}>CHAT</button><button className={view==='node'?'selected':''} onClick={()=>setView('node')}>ATLAS NODE</button></nav><button onClick={()=>refresh()}>REFRESH STATUS</button></div>{view==='chat'?<iframe title="Atlas Chat" src="http://127.0.0.1:8090"/>:<NodeDashboard/>}</div>;
  return <main className="shell"><header><div className="brand"><span className="mark">✦</span><b>ATLAS</b><small>RUST DESKTOP // LOCAL-FIRST RUNTIME</small></div><button onClick={start} disabled={busy}>{busy?'STARTING…':'RETRY START'}</button></header><section className="hero"><div><label>DESKTOP BOOTSTRAP</label><h1>Your local AI workspace is coming online.</h1><p>The Rust desktop shell supervises only the processes it starts. Your existing Atlas web interface, chats, MCP host and local models remain in the project folder.</p><p className="message">{message}</p></div><div className="ctx">LOCAL FIRST<br/><strong>RUST + REACT</strong><br/><small>PYTHON COMPATIBILITY BRIDGE</small></div></section><section className="grid"><article><label>ATLAS API · 8090</label><strong className={health?.atlas_api?'ok':'bad'}>{health?.atlas_api?'ONLINE':'WAITING'}</strong><small>{health?.atlas_api_detail||'Checking readiness…'}</small></article><article><label>LLAMA-SWAP · 8080</label><strong className={health?.llama_swap?'ok':'bad'}>{health?.llama_swap?'ONLINE':'WAITING'}</strong><small>{health?.llama_detail||'Checking readiness…'}</small></article><article><label>CPU</label><strong>{metrics?metrics.cpu_percent.toFixed(1)+'%':'—'}</strong><small>System-wide usage</small></article><article><label>MEMORY</label><strong>{metrics?(metrics.memory_used_bytes/1073741824).toFixed(1)+' GB':'—'}</strong><small>{metrics?`${memoryPct.toFixed(1)}% of ${(metrics.memory_total_bytes/1073741824).toFixed(1)} GB`:'Waiting'}</small><div className="bar"><i style={{width:`${memoryPct}%`}}/></div></article></section>{error&&<pre className="error">{error}{'\n\n'}Check that Python 3, llama-swap and the configured files in settings.json are available. Logs: logs/atlas-server.log and logs/llama-swap.log.</pre>}<section className="activity"><label>RUNTIME CONTRACT</label><p>Existing UI and Python orchestration are retained as a compatibility layer for this test build. MCP discovery and tool execution are wired into normal model chat. Rust owns desktop startup, health checks, system telemetry and shutdown. Tool execution is audited; execution alone is never labelled VERIFIED.</p><div className="states"><span className="verified">VERIFIED · independent proof</span><span className="unverified">EXECUTED_UNVERIFIED · tool ran</span><span className="failed">FAILED · execution/verification failed</span></div></section><footer>ATLAS · NO GLOBAL TASKKILL · NO DATA RESET · EXISTING PYTHON UI PRESERVED</footer></main>;
}
