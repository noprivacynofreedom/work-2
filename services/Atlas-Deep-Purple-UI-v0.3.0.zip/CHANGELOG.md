# Changelog

## v0.3.0
- Preserved the existing Atlas layout and local-first technical identity.
- Introduced a deeper aubergine/purple palette with lilac highlights.
- Refined cards, borders, shadows, toolbar, navigation selection and model controls.
- Replaced developer-facing bootstrap copy with a compact branded loading screen.
- Added reduced-motion handling and responsive toolbar refinements.
