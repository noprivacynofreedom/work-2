# Atlas Deep Purple UI v0.3.0

This is the next visual iteration of the existing Atlas desktop UI. It preserves the current layout,
chat iframe, Atlas Node view, and model runtime controls while deepening the purple palette and
polishing the desktop chrome.

## Visual direction
- Near-black aubergine base (`#100b1a`) with restrained purple ambient lighting.
- Layered violet panels, subtle borders, soft depth, and lilac typography.
- Clear selected state for CHAT / ATLAS NODE.
- Model controls styled as part of the native Atlas toolbar.
- Small branded bootstrap screen instead of exposing developer setup instructions.

## Apply
1. Keep the UI checkpoint archive as your rollback point.
2. Close Atlas.
3. Extract this ZIP into `F:\APP-DEV\projects\atlas-chat\atlas-rust-desktop`, preserving folders.
4. Build:

```powershell
cd "F:\APP-DEV\projects\atlas-chat\atlas-rust-desktop"
npm run build
npm run tauri build
```

## Compatibility
This UI overlay expects the model runtime commands and React model controls from
`Atlas-Background-Model-Controls-v0.2.0` to already be present. It does not modify backend,
settings, chat history, or user data.

## Validation
- ZIP integrity checked after packaging.
- No visual screenshot or Windows production build was available in this environment.
- Review on the target display after building; this is a CSS/HTML refinement, not a claim of
  pixel-perfect verification against the running app.
